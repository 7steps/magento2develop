<?php
return [
    'backend' => [
        'frontName' => 'jds_adm'
    ],
    'crypt' => [
        'key' => '409e205aab77c1a31c6039d79e7c1665'
    ],
    'db' => [
        'table_prefix' => '',
        'connection' => [
            'default' => [
                'host' => 'jds-mysql-v2.ctarq5gkn5hp.ap-northeast-1.rds.amazonaws.com',
                'dbname' => 'jdsmagento2',
                'username' => 'jdsmaster',
                'password' => 'oresama5963',
                'active' => '1'
            ]
        ]
    ],
    'resource' => [
        'default_setup' => [
            'connection' => 'default'
        ]
    ],
    'x-frame-options' => 'SAMEORIGIN',
    'MAGE_MODE' => 'default',
    'session' => [
        'save' => 'files'
    ],
    'cache_types' => [
        'config' => 1,
        'layout' => 1,
        'block_html' => 1,
        'collections' => 1,
        'reflection' => 1,
        'db_ddl' => 1,
        'eav' => 1,
        'customer_notification' => 1,
        'config_integration' => 1,
        'config_integration_api' => 1,
        'full_page' => 1,
        'translate' => 1,
        'config_webservice' => 1,
        'compiled_config' => 1,
        'fishpig_wordpress' => 1
    ],
    'install' => [
        'date' => 'Sun, 26 Aug 2018 03:20:24 +0000'
    ],
    'system' => [
        'default' => [
            'dev' => [
                'debug' => [
                    'debug_logging' => '0'
                ]
            ]
        ]
    ]
];
