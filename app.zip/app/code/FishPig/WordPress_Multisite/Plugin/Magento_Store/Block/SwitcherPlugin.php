<?php
/*
 *
 *
 *
 */
namespace FishPig\WordPress_Multisite\Plugin\Magento_Store\Block;

/* Constructor Args */
use Magento\Framework\App\Request\Http as Request;
use Magento\Framework\UrlInterface;

/* Subject */
use Magento\Store\Block\Switcher;

/* Misc */
use Magento\Store\Model\Store;

class SwitcherPlugin
{
	/*
	 *
	 *
	 *
	 */
	public function __construct(Request $request, UrlInterface $url)
	{
		$this->request = $request;
		$this->url     = $url;
	}
	
	/*
	 * Change the store swicher URL
	 *
	 * @param 	\Magento\Store\Block\Switcher	$subject
	 * @param 	\Closure											$callback
	 * @param 	\Magento\Store\Model\Store		$store
	 * @param 	array													$data = []
	 * @return	string
	 */
	public function aroundGetTargetStorePostData($subject, \Closure $callback, Store $store, $data = [])
	{
		// Get original result
		$originalResult = $callback($store, $data);
		
		// If not WordPress module, return original
		if ($this->request->getModuleName() !== 'wordpress') {
			return $originalResult;
		}

		// Get the request string used to generate current URL so we can remove it
		$requestString = $this->url->escape(
			preg_replace(
				'/\?.*?$/',
				'',
				ltrim($this->request->getRequestString(), '/')
			)
		);
		
		if (!$requestString) {
			return $originalResult;
		}
		
		// Generate new URL
		$newUrl = str_replace('/' . $requestString, '/', $store->getCurrentUrl(true));
		
		$newResult = json_decode($originalResult, true);
		
		$newResult['action'] = $newUrl;
		
		return json_encode($newResult);
	}
}
