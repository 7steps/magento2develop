<?php
/*
 *
 */
namespace FishPig\WordPress_Multisite\Plugin\FishPig_WordPress\Model;

/* Constructor Args */
use FishPig\WordPress\Model\ResourceConnection;
use FishPig\WordPress\Model\Network;

/* Subject */
use FishPig\WordPress\Model\OptionManager;

/* Misc */
use Closure;

class OptionManagerPlugin
{
	/*
	 * @var ResourceConnection
	 */
	protected $resourceConnection;
	
	/*
	 * @var Network
	 */
	protected $network;

	/*
	 *
	 *
	 *
	 */
	public function __construct(ResourceConnection $resourceConnection, Network $network)
	{
		$this->resourceConnection = $resourceConnection;
		$this->network            = $network;
	}
	/*
	 * Get a site option.
	 *
	 * @param  OptionManager $optionManager
	 * @param  string        $key
	 * @return mixed
	 */
	public function aroundGetSiteOption(OptionManager $optionManager, Closure $callback, $key)
	{
		$select = $this->resourceConnection->getConnection()
			->select()
			->from($this->resourceConnection->getTable('wordpress_site_meta'), 'meta_value')
			->where('meta_key = ?', $key)
			->where('site_id=?', $this->network->getSiteId())
			->limit(1);

		if ($value = $this->resourceConnection->getConnection()->fetchOne($select)) {
			return $value;
		}

		return $callback();
	}
}
