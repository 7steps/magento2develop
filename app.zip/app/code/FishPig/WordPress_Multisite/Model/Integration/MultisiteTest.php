<?php
/*
 *
 */
namespace FishPig\WordPress_Multisite\Model\Integration;

/* Constructor Args */
use FishPig\WordPress\Model\WPConfig;

/* Misc */
use FishPig\WordPress\Model\Integration\IntegrationException;

class MultisiteTest
{
	/*
	 *
	 *
	 */
	protected $wpConfig;

	/*
	 *
	 *
	 */
	public function __construct(WPConfig $wpConfig)
	{
		$this->wpConfig = $wpConfig;
	}
	
	/*
	 *
	 *
	 */
	public function runTest()
	{
		if (!$this->wpConfig->getData('MULTISITE')) {
			IntegrationException::throwException(
				'The WordPress Network has not been enabled.'
			);
		}
		
		if ($this->wpConfig->getData('SUBDOMAIN_INSTALL')) {
			IntegrationException::throwException(
				'The WordPress Network is configured to use sub-domains, which is not supported. Change the Network to use sub-directories.'
			);
		}

		return $this;
	}
}
