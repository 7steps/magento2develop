<?php
/*
 *
 */
namespace FishPig\WordPress\Model;

class Logger extends \Monolog\Logger
{
}