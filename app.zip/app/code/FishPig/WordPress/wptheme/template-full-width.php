<?php
/**
 * Template Name: Full Width (1 Column)
 */

get_template_part('index');
