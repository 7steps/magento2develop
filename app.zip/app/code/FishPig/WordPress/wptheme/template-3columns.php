<?php
/**
 * Template Name: 3 Columns
 */

get_template_part('index');
