<?php
/*
 *
 */

if (is_active_sidebar('sidebar-1')) {
	dynamic_sidebar('sidebar-1');
}
else if (is_active_sidebar('sidebar-2')) {
	dynamic_sidebar('sidebar-2');	
}

