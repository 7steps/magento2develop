<?php
/**
 * Template Name: 2 Columns Left
 */

get_template_part('index');
