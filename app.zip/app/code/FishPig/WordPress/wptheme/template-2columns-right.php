<?php
/**
 * Template Name: 2 Columns Right
 */

get_template_part('index');
